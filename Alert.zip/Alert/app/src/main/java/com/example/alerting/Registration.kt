package com.example.alerting

import android.content.Intent
import android.location.Address
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class Registration : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)
        val name: EditText = findViewById(R.id.name)
        val address: EditText = findViewById(R.id.address)
        val h_contineous: EditText = findViewById(R.id.h_condition)
        val Register: Button = findViewById(R.id.Register)
        val phone:EditText = findViewById(R.id.phone)
        Register.setOnClickListener {
            /* variable declaration*/
            val Name = name.text.toString()
            val Address = address.text.toString()
            val Condition = h_contineous.text.toString()
            val Phone = phone.text.toString()
            /* lopping using if else statement*/
            if (Name.isEmpty()) {
                name.requestFocus()
                name.setError("please Enter your Name")
            } else if (Address.isEmpty()) {
                address.requestFocus()
                address.setError("please address is needed")
            } else if (Phone.isEmpty()) {
                phone.requestFocus()
                phone.setError("please enter phone no")
            } else if (Condition.isEmpty()) {
                h_contineous.requestFocus()
                h_contineous.setError("please Enter health condition")
            }
                    Toast.makeText(this@Registration, " Register successful", Toast.LENGTH_LONG).show()
            /* clear the text after writing and submit*/
                    name.text.clear()
                    address.text.clear()
                    phone.text.clear()
                    h_contineous.text.clear()

                    val intent = Intent(this@Registration, Complete::class.java)
                    startActivity(intent)



            }
        }
    }
